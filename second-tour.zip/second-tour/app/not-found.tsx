import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-2xl font-semibold text-navy">
        Cette page n&apos;existe pas
      </h1>
      <p className="mt-3 max-w-sm text-navy/70">
        Le lien est peut-être incomplet ou la page a été déplacée.
      </p>
      <Link
        href="/"
        className="mt-6 inline-flex items-center justify-center rounded-lg bg-ember px-5 py-3 text-sm font-medium text-cream"
      >
        Retour à l&apos;accueil
      </Link>
    </main>
  );
}
