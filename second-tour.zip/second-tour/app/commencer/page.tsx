import Link from "next/link";

export default function Commencer() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-2xl font-semibold text-navy">
        Le paiement arrive dans quelques jours
      </h1>
      <p className="mt-3 max-w-sm text-navy/70">
        Cette page affichera bientôt le paiement en ligne. En attendant,
        contactez-nous directement pour démarrer.
      </p>
      <Link
        href="/"
        className="mt-6 inline-flex items-center justify-center rounded-lg border border-navy/20 px-5 py-3 text-sm font-medium text-navy"
      >
        Retour à l&apos;accueil
      </Link>
    </main>
  );
}
