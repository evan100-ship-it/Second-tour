import Link from "next/link";

export default function MentionsLegales() {
  return (
    <main className="mx-auto max-w-xl px-6 py-16">
      <h1 className="font-display text-2xl font-semibold text-navy">
        Mentions légales
      </h1>
      <p className="mt-4 text-navy/70">
        Cette page sera complétée à l&apos;étape 9 du build, avec vos
        informations légales réelles (raison sociale, SIRET, adresse).
      </p>
      <Link href="/" className="mt-8 inline-block text-sm text-ember">
        ← Retour à l&apos;accueil
      </Link>
    </main>
  );
}
